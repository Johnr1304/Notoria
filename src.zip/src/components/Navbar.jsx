import {
  Search,
  Bell,
  Moon,
  UserCircle2,
} from "lucide-react";

function Navbar() {
  return (
    <header className="bg-white border-b border-gray-200 h-20 px-8 flex items-center justify-between">

      {/* Search */}

      <div className="relative w-[450px]">

        <Search
          size={20}
          className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"
        />

        <input
          type="text"
          placeholder="Search your notes..."
          className="w-full pl-12 pr-4 py-3 rounded-xl border border-gray-300 outline-none focus:ring-2 focus:ring-indigo-500"
        />

      </div>

      {/* Right Side */}

      <div className="flex items-center gap-5">

        <button className="relative">

          <Bell
            size={22}
            className="text-gray-600 hover:text-indigo-600 cursor-pointer"
          />

          <span className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full"></span>

        </button>

        <button>

          <Moon
            size={22}
            className="text-gray-600 hover:text-indigo-600 cursor-pointer"
          />

        </button>

        <div className="flex items-center gap-3">

          <UserCircle2
            size={42}
            className="text-indigo-600"
          />

          <div>

            <h3 className="font-semibold">
              John Britto
            </h3>

            <p className="text-sm text-gray-500">
              Welcome Back
            </p>

          </div>

        </div>

      </div>

    </header>
  );
}

export default Navbar;