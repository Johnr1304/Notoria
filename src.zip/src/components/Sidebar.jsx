import {
  NotebookPen,
  Plus,
  BookOpen,
  Tags,
  Archive,
  Settings,
  LogOut,
} from "lucide-react";

import { useNavigate } from "react-router-dom";


function Sidebar() {

  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("currentUser");
    localStorage.removeItem("isLoggedIn");

    navigate("/login");
  };

  
  return (
    <aside className="w-72 h-screen bg-white border-r border-gray-200 flex flex-col justify-between">

      {/* Top Section */}
      <div>

        {/* Logo */}
        <div className="px-8 py-8">
          <h1 className="text-3xl font-extrabold text-indigo-600">
            Notoria
          </h1>

          <p className="text-gray-500 mt-1">
            Organize Smarter
          </p>
        </div>

        {/* New Note Button */}
        <div className="px-5">
          <button className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-xl flex items-center justify-center gap-2 transition-all">
            <Plus size={20} />
            New Note
          </button>
        </div>

        {/* Menu */}
        <nav className="mt-10 space-y-2 px-4">

          <button className="flex items-center gap-3 w-full p-3 rounded-xl bg-indigo-50 text-indigo-600 font-medium">
            <NotebookPen size={20} />
            All Notes
          </button>

          <button className="flex items-center gap-3 w-full p-3 rounded-xl hover:bg-gray-100">
            <BookOpen size={20} />
            Notebooks
          </button>

          <button className="flex items-center gap-3 w-full p-3 rounded-xl hover:bg-gray-100">
            <Tags size={20} />
            Tags
          </button>

          <button className="flex items-center gap-3 w-full p-3 rounded-xl hover:bg-gray-100">
            <Archive size={20} />
            Archive
          </button>

          <button className="flex items-center gap-3 w-full p-3 rounded-xl hover:bg-gray-100">
            <Settings size={20} />
            Settings
          </button>

        </nav>
      </div>

      {/* Logout */}
      <div className="p-5">
        <button 
        onClick={handleLogout}
        className="w-full bg-red-500 hover:bg-red-600 text-white py-3 rounded-xl flex items-center justify-center gap-2 transition-all">
          <LogOut size={20} />
          Logout
        </button>
      </div>

    </aside>
  );
}

export default Sidebar;