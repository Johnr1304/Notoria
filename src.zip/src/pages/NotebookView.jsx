import React from 'react'

function NotebookView() {
  return (
    <h1>
        NotebookView
    </h1>
  )
}

export default NotebookView