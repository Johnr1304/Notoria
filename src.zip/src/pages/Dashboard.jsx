import { useEffect, useState } from "react";
import api from "../services/api";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import NoteCard from "../components/NoteCard";
import NoteModal from "../components/NoteModal";
import Masonry from "react-masonry-css";

function Dashboard() {
  const [notes, setNotes] = useState([]);

  const [showModal, setShowModal] = useState(false);

  const [editingNote, setEditingNote] = useState(null);

  // Get logged in user
const user = JSON.parse(localStorage.getItem("currentUser"));

  // Fetch Notes
  useEffect(() => {
    fetchNotes();
  }, []);

  const fetchNotes = async () => {
    try {
      const response = await api.get(
        `/notes?userId=${user.id}&archived=false&trashed=false`
      );

      console.log("Fetched Notes:", response.data);
      
      setNotes(response.data);
    } catch (error) {
      console.log(error);
    }
  };

  const addNote = async (note) => {
    try {
    await api.post("/notes", {
      ...note,
      userId: user.id,
      trashed: false,
    });

    await fetchNotes();

    setShowModal(false);

  } catch (error) {
    console.log(error);
  }
  };

    const updateNote = async (updatedNote) => {
  try {

    await api.put(`/notes/${updatedNote.id}`, updatedNote);

    await fetchNotes();

    setEditingNote(null);

    setShowModal(false);

  } catch (error) {
    console.log(error);
  }
};

  const deleteNote = async (id) => {
  try {

    const note = notes.find((n) => n.id === id);

    await api.put(`/notes/${id}`, {
      ...note,
      trashed: true,
    });

    await fetchNotes();

  } catch (error) {
    console.log(error);
  }
};

  // Statistics
  const totalNotes = notes.length;

  const pinnedNotes = notes.filter(
    (note) => note.pinned
  ).length;

  const archivedNotes = notes.filter(
    (note) => note.archived
  ).length;

  const activeNotes = totalNotes - archivedNotes;

  const breakpointColumnsObj = {
     default: 3,
     1100: 2,
     700: 1,
    };

  return (
    <div className="flex min-h-screen bg-slate-100">

      {/* Sidebar */}

      <Sidebar />

      {/* Main */}

      <div className="flex-1 flex flex-col">

        {/* Navbar */}

        <Navbar />

        {/* Main Content */}

        <main className="p-8">

          {/* Header */}

          <div className="flex justify-between items-center">

            <div>

              <h1 className="text-4xl font-bold">
                Welcome Back 👋
              </h1>

              <p className="text-gray-500 mt-2">
                Organize your ideas smarter with Notoria.
              </p>

            </div>

            <button
             type="button"
             onClick={() => setShowModal(true)}
              className="bg-indigo-600 text-white px-6 py-3 rounded-xl hover:bg-indigo-700">
              + New Note
            </button>

          </div>

          {/* Statistics */}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-10">

            {/* Total */}

            <div className="bg-white rounded-2xl shadow-sm p-6 border-l-4 border-indigo-600 hover:shadow-lg transition">

              <h3 className="text-gray-500">
                Total Notes
              </h3>

              <h1 className="text-4xl font-bold mt-3">
                {totalNotes}
              </h1>

            </div>

            {/* Pinned */}

            <div className="bg-white rounded-2xl shadow-sm p-6 border-l-4 border-yellow-500 hover:shadow-lg transition">

              <h3 className="text-gray-500">
                Pinned Notes
              </h3>

              <h1 className="text-4xl font-bold mt-3">
                {pinnedNotes}
              </h1>

            </div>

            {/* Archive */}

            <div className="bg-white rounded-2xl shadow-sm p-6 border-l-4 border-gray-500 hover:shadow-lg transition">

              <h3 className="text-gray-500">
                Archived Notes
              </h3>

              <h1 className="text-4xl font-bold mt-3">
                {archivedNotes}
              </h1>

            </div>

            {/* Active */}

            <div className="bg-white rounded-2xl shadow-sm p-6 border-l-4 border-green-500 hover:shadow-lg transition">

              <h3 className="text-gray-500">
                Active Notes
              </h3>

              <h1 className="text-4xl font-bold mt-3">
                {activeNotes}
              </h1>

            </div>

          </div>

          {/* Notes Section */}

          <div className="mt-10">

            {notes.length === 0 ? (

              <div className="bg-white rounded-2xl shadow p-16 text-center">

                <h2 className="text-3xl font-bold mb-4">
                  No Notes Yet 📝
                </h2>

                <p className="text-gray-500">
                  Click on "New Note" to create your first note.
                </p>

              </div>

            ) : (

              <Masonry
  breakpointCols={breakpointColumnsObj}
  className="flex gap-6"
  columnClassName="space-y-6"
>
  {notes.map((note) => (
    <NoteCard
      key={note.id}
      note={note}
      onDelete={deleteNote}
      onEdit={() => {
        setEditingNote(note);
        setShowModal(true);
      }}
    />
  ))}
</Masonry>

            )}

          </div>

        </main>
          {showModal && (

        <NoteModal
            onClose={() => {
                setShowModal(false);
                setEditingNote(null);
    }}
    note={editingNote}
    onSave={editingNote ? updateNote : addNote}
/>

)}
      </div>

    </div>
  );
}

export default Dashboard;